
class AppApiNames
{
  static String baseurl ="http://mysspdev.pilvisystems.com";
  static String moduleTimesheet ="/TimeSheetApi.php";
  static String method_project_list ="/getProjectList";

}