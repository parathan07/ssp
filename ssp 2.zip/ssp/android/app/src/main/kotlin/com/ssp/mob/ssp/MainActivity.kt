package com.ssp.mob.ssp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
